<!-- <! Login page HTML> -->

<?php

    session_start();

    if (isset($_SESSION["user_exists"])) {
        header('location:scrollbar.html');  
    }

    $host="localhost";
    $user="root";
    $pass="";
    $db="proj";

    $con = mysqli_connect("localhost", "root", "", "proj");

    //mysqli_connect($host,$user,$pass);
    //mysqli_select_db("proj");

    if(isset($_POST['logid']))
    {
        $uname=$_POST['logid'];
        $pass=$_POST['ps'];

        $sql="select * from register where email='".$uname."' AND password='".$pass."' limit 1";

        $result=$con->query($sql);

        if(mysqli_num_rows($result)==1){
            $_SESSION['user_exists'] = true;
            header('location:scrollbar.html');
        }
    }
?>

<html>
<head>
<link rel="stylesheet" href="login.css">
<!-- <! font audiowide> -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Audiowide&display=swap" rel="stylesheet">
<!-- <! font short Itim> -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Itim&display=swap" rel="stylesheet">
</head>
<body>
<div id="bg-img"></div>

<div id="bg-text">
  <form method=POST>
		<img src="Img/logo.png"><br>
  		<label for="fname">Login ID:</label><br>
  		<input type="text" id="logid" name="logid"><br>
  		<label for="lname">Password:</label><br>
  		<input type="password" id="ps" name="ps"><br>
		<button type="submit" id="sub" name="sub" value="Log-in">Log-in</button><br>
		<a id="fgp1" href="forgot.html">forgot password??</a>
		<p>|</p>
		<a id="fgp2" href="regist.php">		Click here if you Don't have account</a>
	</form>
</div>
</body>
</html>