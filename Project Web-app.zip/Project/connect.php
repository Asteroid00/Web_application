<?php
$conn = mysqli_connect("localhost","root","","proj");
if($conn)
{
   // echo "don";
}
else{
    die();
}

?>