function valid()
	{
		let ID=document.getElementById('nm');
		let id_val=/^([^0-9\W]*)$/;

		// let NO=document.getElementById('no');
		// let no_val=/\d{10}$/;

		let MAIL=document.getElementById('mail');
		let mail_val=/^[a-z0-9_.-]+[@]{1}[a-z_.-]+[.]+[a-z]{2,4}$/;

		if(id_val.test(nm.value.trim()))
		{
			document.getElementById('sml_nm').textContent="Valid Name";
			document.getElementById('sml_nm').style.color='rgb(127,255,0)';
		}
		else
		{
			document.getElementById('sml_nm').textContent="Invalid Name";
			document.getElementById('sml_nm').style.color='rgb(255, 0, 76)';
		}

		// if(no_val.test(no.value.trim()))
		// {
		// 	document.getElementById('sml_no').textContent="Valid Phone-No";
		// 	document.getElementById('sml_no').style.color='rgb(127,255,0)';
		// }
		// else
		// {
		// 	document.getElementById('sml_no').textContent="Invalid Phone-No";
		// 	document.getElementById('sml_no').style.color='rgb(255, 0, 76)';
		// }

		if(mail_val.test(mail.value.trim()))
		{
			document.getElementById('sml_mail').textContent="Valid Email";
			document.getElementById('sml_mail').style.color='rgb(127,255,0)';
		}
		else
		{
			document.getElementById('sml_mail').textContent="Invalid Email";
			document.getElementById('sml_mail').style.color='rgb(255, 0, 76)';
		}
	}
	document.getElementById('nm').addEventListener("keyup",valid);
	document.getElementById('no').addEventListener("keyup",valid);
	document.getElementById('mail').addEventListener("keyup",valid);