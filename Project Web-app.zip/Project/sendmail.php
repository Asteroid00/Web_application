<?php
require_once('phpmailer/src/PHPMailer.php');

$mail= new PHPMailer();
$mail->isSMTP();
$mail->SMTPAuth=true;
$mail->SMTPSecure='ssl';
$mail->Host='smtp.gmail.com';
$mail->Port='465';
$mail->isHTML();
$mail->Username='socialnetworkmail2@gmail.com';
$mail->Password='368276b2fb0439a3';
$mail->SetFrom('sachitdalwadi10@gmail.com');
$mail->Subject='Hello World';
$mail->AddAddress('jayrohit570@gmail.com');
$mail->Send();
?>