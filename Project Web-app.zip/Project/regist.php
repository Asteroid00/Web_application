<!-- <! Login page HTML> -->

<?php
include 'connect.php';


if(isset($_POST['submit'])){
	$name = $_POST['name'];
	$pno = $_POST['pno'];
	$email = $_POST['mail'];
	$dob = $_POST['bd'];
	$pass = $_POST['pass'];

	$sql = "INSERT INTO register VALUES ('$name', $pno, '$email','$dob','$pass')";
  
	 $res=mysqli_query($conn,$sql);
	 if($res){
		header('location: ./bootstrap-5.1.3-examples/bootstrap-5.1.3-examples/pricing/index.html');
		exit();
	 }
	// $res=mysqli_query($conn,$sql);
	
	//  if ($conn->query($sql) === TRUE) {
	//    echo '<script type="text/javascript">';
	//    echo 'alert("Register Successfully")';
	//    echo '</script>';
	//  } else {
	//      echo '<script type="text/javascript">';
	//      echo 'alert("Something went wrong ")';
	//      echo '</script>';
	//  }

	// if($res){
	// 	header('location: ./bootstrap-5.1.3-examples/bootstrap-5.1.3-examples/pricing/index.html');
	// }
}
?>

<html>

<head>
	<link rel="stylesheet" href="regist.css">
	<!-- <! font audiowide> -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Audiowide&display=swap" rel="stylesheet">
	<!-- <! font short Itim> -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Itim&display=swap" rel="stylesheet">
	<style>
		input::-webkit-outer-spin-button,
		input::-webkit-inner-spin-button {
			-webkit-appearance: none;
			margin: 0;
		}
	</style>

</head>

<body>

	<div id="bg-img"></div>

	<div id="bg-text">
		<form  method="POST" name="myform" action="">
			<img id="logo" src="Img/logo.png">
			<img id="movie1" src="Img/try3.jpg"><br>
			Name:<small id="sml_nm"></small><br>
			<input type="text" id="nm" name="name" size="25" pattern="(*[a-zA-Z])" required><br>
			Phone No:<small id="sml_no"></small><br>
			<input type="number" id="no" name="pno" size="25" pattern="(*\d){10}"><br>
			Email:<small id="sml_mail"></small><br>
			<input type="text" id="mail" name="mail" size="25"><br>
			Birthday:<br>
			<input type="date" id="bday" name="bd"><br>
			Password:<br>
			<input type="password" id="ps1" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required size="25">
			<p
				style="font-size: small; font-family: Verdana; margin-top: 2px; margin-bottom: 2px; color: rgb(135, 231, 135);">
				8 Character Long, Conatin Number <br> and One Special Character</p>
			Confirm Password:<br>
			<input type="password" name="pass" id="ps2" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required
				size="25"> <br><br>
			<button type="submit" value="submit" id="reg" name="submit">Register</button><br>
		</form>
	</div>
	<script src="regi_js.js">
	</script>
</body>

</html>