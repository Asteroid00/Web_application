<?php
    
    $conn=mysqli_connect("localhost","root","","proj");


	if(isset($_POST['submit'])){
		$name = $_POST['name'];
        $pno = $_POST['pno'];
        $email = $_POST['mail'];
        $dob = $_POST['bd'];
        $pass = $_POST['pass'];

        $sql = "INSERT INTO register VALUES ('$name', $pno, '$email','$dob','$pass')";
        
        // if ($conn->query($sql) === TRUE) {
        //   echo '<script type="text/javascript">';
        //   echo 'alert("Register Succeddfully")';
        //   echo '</script>';
        // } else {
        //     echo '<script type="text/javascript">';
        //     echo 'alert("Something went wrong ")';
        //     echo '</script>';
        // }
	}
?>